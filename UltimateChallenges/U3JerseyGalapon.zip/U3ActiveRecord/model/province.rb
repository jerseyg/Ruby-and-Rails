class Province < ActiveRecord::Base
  has_many :customer
end
