class Categories < ActiveRecord::Base
	has_many :product
end
